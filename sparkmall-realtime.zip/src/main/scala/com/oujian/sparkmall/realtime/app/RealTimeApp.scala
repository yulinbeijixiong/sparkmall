package com.oujian.sparkmall.realtime.app

import com.oujian.sparkmall.realtime.bean
import com.oujian.sparkmall.realtime.bean.AdsLog
import com.oujian.sparkmall.realtime.util.MyKafkaUtil
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object RealTimeApp {
  def main(args: Array[String]): Unit = {
    val sparkConf: SparkConf = new SparkConf().setMaster("local[*]").setAppName("realtimeApp")
    val context = new SparkContext(sparkConf)
    val scc = new StreamingContext(context,Seconds(5))
    val recordDstream: InputDStream[ConsumerRecord[String, String]] = MyKafkaUtil.getKafkaStream("ads_log", scc)

    val ds: DStream[AdsLog] = recordDstream.map { record =>
      val adsLongString: String = record.value()
      val adsLogArray: Array[String] = adsLongString.split(" ")
      bean.AdsLog(adsLogArray(0).toLong, adsLogArray(1), adsLogArray(2), adsLogArray(4).toLong, adsLogArray(3).toInt)
    }
//  val value: DStream[AdsLog] = BlackListHandler.checkBlackList(ds)
//    BlackListHandler.updateUserAdsCount(value)
//    val value: DStream[(String, Long)] = AreaAdCount.handle(ds,context)
//    AreaTop3AdHandle.handle(value)
    HourRecentAdClick.hand(ds)
    scc.start()
    scc.awaitTermination()
  }
}
