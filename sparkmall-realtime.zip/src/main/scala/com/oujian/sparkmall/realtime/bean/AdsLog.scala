package com.oujian.sparkmall.realtime.bean

case class AdsLog (ts:Long,area:String,city:String,uid:Long,adsId:Int)
