package com.oujian.sparkmall.realtime.app

import java.sql.Date
import java.text.SimpleDateFormat
import java.util

import com.oujian.sparkmall.realtime.bean.AdsLog
import com.oujian.sparkmall.realtime.util.RedisUtil
import org.apache.spark.streaming.dstream.DStream
import redis.clients.jedis.Jedis

object BlackListHandler {
  def updateUserAdsCount(adsLogDstream: DStream[AdsLog]): Unit = {

    adsLogDstream.foreachRDD { adsRDD =>
      //      val jedis: Jedis = RedisUtil.getJedisClient
      //
      //      //设置键值 user_ads_daycount
      //      //uid:ads:date vale:count
      //      adsRDD.foreach{
      //        adslog=>
      //          val key="user_ads_daycount"
      //          val date=new SimpleDateFormat("yyyy-MM-dd").format(new Date(adslog.ts))
      //          val field=adslog.uid+":"+adslog.adsId+":"+date
      //          jedis.hincrBy(key,field,1L)
      //      }
      //方便将jedis 传到 excutor
      adsRDD.foreachPartition { adsLogIte =>
        val jedis: Jedis = RedisUtil.getJedisClient
        val key = "user_ads_daycount"
        val backList:String = "back_list"
        adsLogIte.foreach { adsLog =>

          val date = new SimpleDateFormat("yyyy-MM-dd").format(new Date(adsLog.ts))
          val field = adsLog.uid + ":" + adsLog.adsId + ":" + date
          jedis.hincrBy(key, field, 1L)
            val countStr: String = jedis.hget(key, field)

          if (countStr.toLong >= 100L) {
            jedis.sadd(backList, adsLog.uid.toString)
          }
        }
        jedis.close()
      }
    }

  }
  def checkBlackList(adsLogDstream: DStream[AdsLog]) :DStream[AdsLog]={
    //放在transform 会周期性执行，否则只执行一次
    adsLogDstream.transform{rdd=>
      val backList:String = "back_list"
      val client: Jedis = RedisUtil.getJedisClient
      val strings: util.Set[String] = client.smembers(backList)
      client.close()
      rdd.filter{adsLog=> !strings.contains(adsLog.uid.toString) }
    }

  }
}
