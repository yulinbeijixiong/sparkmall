package com.oujian.sparkmall.realtime.app

import java.text.SimpleDateFormat

import com.oujian.sparkmall.realtime.bean.AdsLog
import com.oujian.sparkmall.realtime.util.RedisUtil
import org.apache.spark.SparkContext
import org.apache.spark.streaming.dstream.DStream
import redis.clients.jedis.Jedis

object AreaAdCount {
  def handle(adsLogDstream: DStream[AdsLog], sparkContext: SparkContext): DStream[(String, Long)] = {
    //转换格式
    val cityAd: DStream[(String, Long)] = adsLogDstream.map { adsLog =>
      val date: String = new SimpleDateFormat("yyyy-MM-dd").format(adsLog.ts)
      val key = adsLog.area + ":" + adsLog.city + ":" + adsLog.adsId + ":" + date
      println((key, 1L))
      (key, 1L)

    }
    // 将每一批次进行计数
    sparkContext.setCheckpointDir("./checkpoint")
    val value: DStream[(String, Long)] = cityAd.updateStateByKey { (adsLog: Seq[Long], newCount: Option[Long]) =>
      val sum: Long = adsLog.sum
      val count: Long = newCount.getOrElse(sum) + sum
      println(Some(count))
      Some(count)
    }

    cityAd.foreachRDD { city =>

      city.foreachPartition { rdd =>
        val jedis: Jedis = RedisUtil.getJedisClient
        val redisKey = "area_city_ads_daycount"
        val map: Map[String, String] = rdd.map { case (key, count) =>
          (key, count.toString)

        }.toMap
        import scala.collection.JavaConversions._

        if (map != null && map.size > 0) {
          jedis.hmset(redisKey, map)
        }

        jedis.close()
      }


    }
    value
  }

}
