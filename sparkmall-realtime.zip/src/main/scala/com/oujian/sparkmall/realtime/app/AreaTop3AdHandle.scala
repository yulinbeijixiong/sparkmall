package com.oujian.sparkmall.realtime.app

import com.oujian.sparkmall.realtime.bean.AdsLog
import com.oujian.sparkmall.realtime.util.RedisUtil
import org.apache.spark.streaming.dstream.DStream
import org.json4s.JsonDSL._
import org.json4s.native.JsonMethods
import redis.clients.jedis.Jedis

object AreaTop3AdHandle {
  def handle(adsLogDStream: DStream[(String, Long)]): Unit = {
    //转变结构，去掉city字段，并进行点击量求和
    val areaAdsIdDateDStream: DStream[(String, Long)] = adsLogDStream.map { case (areaCityUidDate, count) =>
      val info: Array[String] = areaCityUidDate.split(":")
      val area = info(0)
      val city = info(1)
      val adsId = info(2)
      val date = info(3)
      (area + ":" + adsId + ":" + date, count)

    }.reduceByKey(_ + _)
    // 转变元组结构，并安日期进行分组
    val areaAdsIdCountGroupByDate: DStream[(String, Iterable[(String, (String, Long))])] = areaAdsIdDateDStream.map { case (key, count) =>
      val areaAdsIdDate: Array[String] = key.split(":")
      val area = areaAdsIdDate(0)
      val adsId = areaAdsIdDate(1)
      val date = areaAdsIdDate(2)
      (date, (area, (adsId, count)))
    }.groupByKey()

    val result: DStream[(String, Map[String, String])] = areaAdsIdCountGroupByDate.map { case (date, areaAdsCountItr) =>
      //按地区进行分组
      val adsCountGroupByArea: Map[String, Iterable[(String, (String, Long))]] = areaAdsCountItr.groupBy { case (area, (adsId, count)) => area }

      val areaTop3AdsCount: Map[String, String] = adsCountGroupByArea.map { case (area, areaAdsCountPerAreaItr) =>
        //去掉冗余字段area
        val adsCountItr: Iterable[(String, Long)] = areaAdsCountPerAreaItr.map { case (area, (adsId, count)) => (area, count) }
        //进行点击量排序，并去前三名
        val adsCountTop3List: List[(String, Long)] = adsCountItr.toList.sortWith(_._2 > _._2).take(3)
        //将scala map集合json化
        val adsCountTop3Json: String = JsonMethods.compact(JsonMethods.render(adsCountTop3List))
        (area, adsCountTop3Json)
      }
      (date, areaTop3AdsCount)
    }
    //写入redis
    result.foreachRDD{rdd=>
      rdd.foreachPartition{dateItr=>
        val jedis: Jedis = RedisUtil.getJedisClient
        dateItr.foreach{case(date,json)=>
        val key="top2_ads_per_day:"+date
          import scala.collection.JavaConversions._
            jedis.hmset(key,json)
        }
        jedis.close()
      }
    }

  }

}
