package com.oujian.sparkmall.realtime.app

import java.text.SimpleDateFormat
import java.util.Date

import com.oujian.sparkmall.realtime.bean.AdsLog
import com.oujian.sparkmall.realtime.util.RedisUtil
import org.apache.spark.streaming.{Minutes, Seconds}
import org.apache.spark.streaming.dstream.DStream
import org.json4s.native.JsonMethods
import redis.clients.jedis.Jedis

object HourRecentAdClick {
  def hand(adsLogDStream: DStream[AdsLog]): Unit = {
    val lastHourDStream: DStream[AdsLog] = adsLogDStream.window(Minutes(60),Seconds(10))
    val adsHourMinuteCountDStrem: DStream[(String, Long)] = lastHourDStream.map { dStream =>
      val hourMinute: String = new SimpleDateFormat("HH:mm").format(new Date(dStream.ts))
      val key = dStream.adsId + "_" + hourMinute
      (key, 1L)

    }.reduceByKey(_ + _)

    val hourMinuteCount: DStream[(String, Iterable[(String, Long)])] = adsHourMinuteCountDStrem.map { case (hourAds, count) =>
      val strings: Array[String] = hourAds.split("_")
      val adsId: String = strings(0)
      val hourMinute: String = strings(1)
      (adsId, (hourMinute, count))
    }.groupByKey()
    val hourMintueCountJsonByAdsDStream: DStream[(String, String)] = hourMinuteCount.map { case (ads, hourCountItr) =>
      import org.json4s.JsonDSL._
      val str: String = JsonMethods.compact(JsonMethods.render(hourCountItr))
      (ads, str)
    }
    hourMintueCountJsonByAdsDStream.foreachRDD{rdd=>
      rdd.foreachPartition{hourMintue=>
        val jedis:Jedis = RedisUtil.getJedisClient
        val key="hour_minuter_ads_click"
        import scala.collection.JavaConversions._
        val map: Map[String, String] = hourMintue.toMap
        if(map!=null&&map.size>0){
          jedis.hmset(key,map)
        }

        jedis.close()
      }

    }

  }
}
